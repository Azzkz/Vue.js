<template>
  <transition name="fade">
    <div class="task-item" :class="{ completed, highPriority }">
      <input
          type="checkbox"
          v-model="task.completed"
          @change="markCompleted"
          class="task-checkbox"
      />
      <span class="task-title">{{ task.title }}</span>
      <button @click="$emit('delete-task', task.id)" class="delete-button">Delete</button>
    </div>
  </transition>
</template>


<script lang="ts">
import { defineComponent, PropType } from 'vue';
import { Task } from '../interfaces/Task';

export default defineComponent({
  props: {
    task: {
      type: Object as PropType<Task>,
      required: true,
    },
  },
  computed: {
    completed() {
      return this.task.completed;
    },
    highPriority() {
      return this.task.priority === 'high';
    },
  },
  methods: {
    markCompleted() {
      this.$emit('task-completed', this.task);
    },
  },
});
</script>
