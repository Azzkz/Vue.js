<template>
  <div class="task-list">
    <form @submit.prevent="addTask">
      <input v-model="newTaskTitle" class="input-box" placeholder="Enter task" />
      <select v-model="newTaskPriority" class="dropdown-box">
        <option value="low">Low</option>
        <option value="medium">Medium</option>
        <option value="high">High</option>
      </select>

      <button type="submit" class="submit-button">Add Task</button>
    </form>

    <div class="task-summary">
      Pending Tasks: {{ pendingTasks }}
    </div>

    <transition-group name="list" tag="div">
      <TaskItem
          v-for="task in sortedTasks"
          :key="task.id"
          :task="task"
          @delete-task="deleteTask"
          @task-completed="markCompleted"
      />
    </transition-group>
  </div>
</template>


<script lang="ts">
import { defineComponent, ref, computed, watch, nextTick } from 'vue';
import { Task } from '../interfaces/Task';
import TaskItem from './item.vue';

export default defineComponent({
  components: { TaskItem },
  setup() {
    const tasks = ref<Task[]>([]);
    const newTaskTitle = ref('');
    const newTaskPriority = ref<'low' | 'medium' | 'high'>('low');
    const taskId = ref(1);

    const addTask = async () => {
      if (!newTaskTitle.value.trim()) return;

      tasks.value.push({
        id: taskId.value++,
        title: newTaskTitle.value,
        priority: newTaskPriority.value,
        completed: false,
      });

      newTaskTitle.value = '';
      newTaskPriority.value = 'low';

      await nextTick();
      scrollToLastTask();
    };

    const deleteTask = (id: number) => {
      tasks.value = tasks.value.filter((task) => task.id !== id);
    };

    const markCompleted = (updatedTask: Task) => {
      const task = tasks.value.find((t) => t.id === updatedTask.id);
      if (task) task.completed = !task.completed;
    };

    const sortedTasks = computed(() =>
        [...tasks.value].sort((a, b) => {
          const priorityOrder = { high: 3, medium: 2, low: 1 };
          return priorityOrder[b.priority] - priorityOrder[a.priority];
        })
    );

    const pendingTasks = computed({
      get: () => tasks.value.filter((task) => !task.completed).length,
    });

    watch(
        tasks,
        () => {
          console.log('Task list updated:', tasks.value);
        },
        { deep: true }
    );

    const scrollToLastTask = () => {
      const taskListElement = document.querySelector('.task-list');
      if (taskListElement) {
        taskListElement.scrollTo(0, taskListElement.scrollHeight);
      }
    };

    return {
      tasks,
      newTaskTitle,
      newTaskPriority,
      addTask,
      deleteTask,
      markCompleted,
      sortedTasks,
      pendingTasks,
    };
  },
});
</script>

