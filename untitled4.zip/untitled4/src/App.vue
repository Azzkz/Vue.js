<template>
  <div id="app">
    <h1>Task Manager</h1>
    <TaskList />
  </div>
</template>

<script lang="ts">
import TaskList from './components/List.vue';

export default {
  name: 'App',
  components: { TaskList },
};
</script>

